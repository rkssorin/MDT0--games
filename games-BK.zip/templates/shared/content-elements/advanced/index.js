const advancedElements = [
  require('./webcam-image-upload')
];

module.exports.advancedElements = advancedElements;