require('./styles.scss');

module.exports = require('./prototype')();