const formElements = [
  require('./checkbox'),
  require('./form-field'),
  require('./form-field-tel'),
  require('./form-field-bet'),
  require('./poll'),
  require('./radio'),
  require('./recaptcha'),
  require('./select'),
  require('./text-area')
];

module.exports.formElements = formElements;