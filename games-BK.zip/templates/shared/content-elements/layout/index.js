const layoutElements = [
	//
	require("./col-one"),
	require("./col-two"),
	require("./col-three"),
	require("./col-four"),
	require("./spacer"),
];

module.exports.layoutElements = layoutElements;
