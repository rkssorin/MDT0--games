const gameElements = [require("./game-cxycle"), require("./game-of-fortune"), require("./game-quizz"), require("./game-animals"), require("./tipp-spiel")];

module.exports.gameElements = gameElements;
